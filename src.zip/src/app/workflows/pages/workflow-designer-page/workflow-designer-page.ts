import { Component, computed, inject } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import {StepsSidebarComponent} from '../../components/steps-sidebar/steps-sidebar';
import {StepConfigPanelComponent} from '../../components/step-config-panel/step-config-panel';
import {WorkflowsFacade} from '../../services/workflows.facade';
import {MonacoStepEditorComponent} from '../../components/monaco-step-editor/monaco-step-editor';
import {InputsPanelComponent} from '../../components/inputs-panel/inputs-panel';
import {VariablesPanelComponent} from '../../components/variables-panel/variables-panel';


@Component({
  standalone: true,
  selector: 'app-workflow-designer-page',
  imports: [
    StepsSidebarComponent,
    StepConfigPanelComponent,
    InputsPanelComponent,
    VariablesPanelComponent,
    MonacoStepEditorComponent
],
  templateUrl: './workflow-designer-page.html',
})
export class WorkflowDesignerPage {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  readonly facade = inject(WorkflowsFacade);

  readonly isNew = computed(() => !this.route.snapshot.paramMap.get('id'));

  async ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) await this.facade.loadWorkflow(id);
    else this.facade.initNewWorkflow();
  }

  async save() {
    if (this.facade.detectCycle()) {
      this.facade.error.set('Dependency cycle detected. Fix step dependencies before saving.');
      return;
    }
    await this.facade.save();
  }

  async publish() {
    if (this.facade.detectCycle()) {
      this.facade.error.set('Dependency cycle detected. Fix step dependencies before publishing.');
      return;
    }
    await this.facade.publish();
  }

  back() {
    this.router.navigate(['/workflows']);
  }
}
