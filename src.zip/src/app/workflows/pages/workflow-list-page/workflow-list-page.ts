import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import {WorkflowsApi} from '../../services/workflows.api';
import {WorkflowSummaryDto} from '../../models/workflow-models';

@Component({
  standalone: true,
  selector: 'app-workflows-list-page',
  imports: [CommonModule, RouterLink],
  templateUrl: './workflow-list-page.html',
})
export class WorkflowListPage {
  private api = inject(WorkflowsApi);
  private router = inject(Router);

  loading = false;
  items: WorkflowSummaryDto[] = [];
  error: string | null = null;

  async ngOnInit() {
    await this.load();
  }

  async load() {
    this.loading = true;
    this.error = null;
    try {
      this.items = await this.api.list().toPromise() ?? [];
    } catch (e: any) {
      this.error = e?.message ?? 'Failed to load workflows';
    } finally {
      this.loading = false;
    }
  }

  openDesigner(id: string) {
    this.router.navigate(['/workflows', id, 'designer']);
  }

  run(id: string) {
    this.router.navigate(['/workflows', id, 'run']);
  }

  runs(id: string) {
    this.router.navigate(['/workflows', id, 'runs']);
  }
}
