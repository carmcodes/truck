import { Component, EventEmitter, Input, Output } from '@angular/core';
import {WorkflowInputDto, WorkflowInputKind} from '../../models/workflow-models';


@Component({
  standalone: true,
  selector: 'app-inputs-panel',
  imports: [],
  template: `
  <div style="border:1px solid #ddd; border-radius:10px; padding:10px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:10px;">
      <div style="font-weight:700">Inputs</div>

      <select (change)="addInput.emit($any($event.target).value)">
        <option value="" selected disabled>+ Add</option>
        @for (k of kinds; track k) {
          <option [value]="k">{{ k }}</option>
        }
      </select>
    </div>

    @if (inputs.length === 0) {
      <div style="opacity:.7;">No inputs defined.</div>
    }

    @for (i of inputs; track i) {
      <div style="border:1px solid #eee; padding:10px; border-radius:10px; margin-bottom:8px;">
        <div style="display:flex; justify-content:space-between; gap:8px; align-items:center;">
          <div>
            <div style="font-weight:600">{{ i.kind }}</div>
            <div style="font-size:12px; opacity:.7;">exposed as: input.{{ i.name }}</div>
          </div>
          <button (click)="deleteInput.emit(i.id)">✕</button>
        </div>
        <div style="margin-top:8px;">
          <label style="font-size:12px; font-weight:600;">Name</label>
          <input style="width:100%;" [value]="i.name"
            (input)="patchInput.emit({ inputId: i.id, patch: { name: $any($event.target).value } })"
            />
          </div>
          <div style="margin-top:8px;">
            <label style="font-size:12px; font-weight:600;">Config (JSON)</label>
            <textarea style="width:100%; height:70px; font-family:monospace;"
              [value]="stringify(i.config)"
              (input)="onConfigChange(i.id, $any($event.target).value)"
            ></textarea>
          </div>
        </div>
      }
    </div>
  `,
})
export class InputsPanelComponent {
  @Input({ required: true }) inputs: WorkflowInputDto[] = [];

  @Output() addInput = new EventEmitter<WorkflowInputKind>();
  @Output() patchInput = new EventEmitter<{ inputId: string; patch: Partial<WorkflowInputDto> }>();
  @Output() deleteInput = new EventEmitter<string>();

  kinds: WorkflowInputKind[] = ['Excel', 'CSV', 'JSON', 'Text', 'HTTP', 'DB'];

  stringify(v: unknown) {
    try { return JSON.stringify(v ?? {}, null, 2); } catch { return '{}'; }
  }

  onConfigChange(inputId: string, raw: string) {
    try {
      const config = JSON.parse(raw);
      this.patchInput.emit({ inputId, patch: { config } });
    } catch {
      // ignore until valid JSON; you can show inline validation if you want
    }
  }
}
