import * as monaco from 'monaco-editor';

import { CharStreams, CommonTokenStream } from 'antlr4ts';
import { CollectingErrorListener } from './collecting-error-listener';
import {LanguageLexer} from '../../../antlr/LanguageLexer';
import {LanguageParser} from '../../../antlr/LanguageParser';

export function applyAntlrDiagnostics(
  model: monaco.editor.ITextModel
): monaco.editor.IMarkerData[] {
  const text = model.getValue();

  const input = CharStreams.fromString(text);
  const lexer = new LanguageLexer(input);
  const tokens = new CommonTokenStream(lexer);
  const parser = new LanguageParser(tokens);

  // remove default console logging
  lexer.removeErrorListeners();
  parser.removeErrorListeners();

  const errorListener = new CollectingErrorListener();
  lexer.addErrorListener(errorListener);
  parser.addErrorListener(errorListener);

  try {
    parser.program(); // 👈 ENTRY RULE FROM YOUR GRAMMAR
  } catch {
    // ANTLR may throw on fatal errors; listener still collects
  }

  return errorListener.errors.map(err => {
    const line = Math.max(1, Math.min(err.line, model.getLineCount()));
    const startColumn = err.column + 1;

    const lineLength = model.getLineLength(line);
    const endColumn = Math.min(startColumn + 1, lineLength + 1);

    return {
      severity: monaco.MarkerSeverity.Error,
      message: normalizeAntlrMessage(err.message),
      startLineNumber: line,
      startColumn,
      endLineNumber: line,
      endColumn,
      source: 'antlr',
    };
  });
}

function normalizeAntlrMessage(msg: string) {
  return msg
    .replace(/^line \d+:\d+\s*/i, '')
    .replace(/<EOF>/g, 'end of file');
}
