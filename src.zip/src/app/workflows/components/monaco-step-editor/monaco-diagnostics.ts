import * as monaco from 'monaco-editor';
import { applyLogicalDiagnostics } from './logical-diagnostics';
import { applyAntlrDiagnostics } from './antlr-diagnostics';

export function applyWorkflowDiagnostics(
  model: monaco.editor.ITextModel
) {
  const logicalMarkers = applyLogicalDiagnostics(model);

  if (logicalMarkers.length > 0) {
    // ❗ DO NOT RUN ANTLR if logic already failed
    monaco.editor.setModelMarkers(model, 'workflow', logicalMarkers);
    return;
  }

  const antlrMarkers = applyAntlrDiagnostics(model);
  monaco.editor.setModelMarkers(model, 'workflow', antlrMarkers);
}
