import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';


import * as monaco from 'monaco-editor';
import { registerWorkflowLanguage } from './monaco-language';
import { registerWorkflowCompletion } from './monaco-completion';
import {detectContextFromGrammar} from './monaco-context';
import {WorkflowVar} from '../../models/workflow-models';
import { applyWorkflowDiagnostics} from './monaco-diagnostics';
import {applyAntlrDiagnostics} from './antlr-diagnostics';

@Component({
  standalone: true,
  selector: 'app-monaco-step-editor',
  imports: [],
  template: `<div #host class="monaco-host"></div>`,
  styleUrls: ['./monaco-step-editor.css'],
})
export class MonacoStepEditorComponent implements AfterViewInit, OnChanges {
  @ViewChild('host', { static: true }) host!: ElementRef<HTMLDivElement>;

  @Input() language: string = 'custom';
  @Input() code: string = '';
  @Input() availableVariables: WorkflowVar[] = [];

  @Output() codeChange = new EventEmitter<string>();

  private editor?: monaco.editor.IStandaloneCodeEditor;
  private model?: monaco.editor.ITextModel;
  private disposers: monaco.IDisposable[] = [];
  private diagTimer: any;

  ngAfterViewInit(): void {
    // register custom language once
    registerWorkflowLanguage();
    registerWorkflowCompletion({
      languageId: 'workflowLang',
      getVariables: () => this.availableVariables,
      getContext: (model, pos) => detectContextFromGrammar(model, pos),
    });

    this.model = monaco.editor.createModel(this.code ?? '', 'workflowLang');

    this.editor = monaco.editor.create(this.host.nativeElement, {
      model: this.model,
      automaticLayout: true,
      minimap: { enabled: false },
      fontSize: 13,
    });

    console.log('Monaco created:', !!this.editor);
    setTimeout(() => this.editor?.layout(), 0);


    this.disposers.push(
      this.model.onDidChangeContent(() => {
        this.codeChange.emit(this.model!.getValue());

        clearTimeout(this.diagTimer);
        this.diagTimer = setTimeout(() => {
          applyWorkflowDiagnostics(this.model!);
        }, 200);
      })
    );

// initial run
    applyWorkflowDiagnostics(this.model);

  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.model) return;

    if (changes['code'] && typeof this.code === 'string' && this.code !== this.model.getValue()) {
      this.model.setValue(this.code);
    }

    if (changes['availableVariables']) {
      applyAntlrDiagnostics(this.model);
    }
  }

  ngOnDestroy(): void {
    this.disposers.forEach(d => d.dispose());
    this.editor?.dispose();
    this.model?.dispose();
  }
}
