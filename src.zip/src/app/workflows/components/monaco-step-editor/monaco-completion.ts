import * as monaco from 'monaco-editor';
import { CompletionContext } from './monaco-context';
import {WorkflowVar} from '../../models/workflow-models';

let registered = false;

export function registerWorkflowCompletion(opts: {
  languageId: string;
  getVariables: () => WorkflowVar[];
  getContext: (model: monaco.editor.ITextModel, position: monaco.Position) => CompletionContext;
}) {
  if (registered) return;
  registered = true;

  monaco.languages.registerCompletionItemProvider(opts.languageId, {
    triggerCharacters: ['.', ' ', '(', '!', '='],
    provideCompletionItems: (model, position) => {
      const ctx = opts.getContext(model, position);
      const vars = opts.getVariables() ?? [];

      // Replace current identifier under cursor nicely
      const word = model.getWordUntilPosition(position);
      const range = new monaco.Range(
        position.lineNumber,
        word.startColumn,
        position.lineNumber,
        word.endColumn
      );

      const suggestions: monaco.languages.CompletionItem[] = [];

      const addKeyword = (kw: string, insertText?: string) => {
        suggestions.push({
          label: kw,
          kind: monaco.languages.CompletionItemKind.Keyword,
          insertText: insertText ?? kw,
          range,
        });
      };

      const addVar = (v: WorkflowVar) => {
        suggestions.push({
          label: v.name,
          kind: monaco.languages.CompletionItemKind.Variable,
          insertText: v.name,
          detail: `variable (${v.kind})`,
          range,
        });
      };

      const addBoolLiterals = () => {
        addKeyword('true');
        addKeyword('false');
      };

      // --- Your requested behavior ---
      if (ctx.kind === 'StartOfLine') {
        addKeyword('if', 'if ');
        addKeyword('while', 'while ');
        for (const v of vars) addVar(v);
        return { suggestions };
      }

      if (ctx.kind === 'IfCondition' || ctx.kind === 'WhileCondition') {
        // boolean-only suggestions
        for (const v of vars.filter(x => x.kind === 'bool')) addVar(v);

        // helpful boolean expression building blocks (your grammar supports these)
        addKeyword('!', '!');
        addKeyword('and', 'and ');
        addKeyword('or', 'or ');
        addKeyword('(', '(');
        addBoolLiterals();

        return { suggestions };
      }

      // General: allow everything + useful keywords
      for (const v of vars) addVar(v);
      addKeyword('null');
      addBoolLiterals();
      addKeyword('if', 'if ');
      addKeyword('while', 'while ');
      return { suggestions };
    },
  });
}
