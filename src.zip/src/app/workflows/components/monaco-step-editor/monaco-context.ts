import * as monaco from 'monaco-editor';

export type CompletionContextKind =
  | 'StartOfLine'
  | 'IfCondition'
  | 'WhileCondition'
  | 'General';

export interface CompletionContext {
  kind: CompletionContextKind;
}

function stripLeadingWs(s: string) {
  return s.replace(/^\s+/, '');
}

/**
 * Finds whether cursor is in the condition part of:
 *   if <expression> { ... }
 *   while <expression> { ... }
 *
 * Grammar says expression comes immediately after keyword and ends before block '{'.
 * We also avoid triggering inside strings.
 */
export function detectContextFromGrammar(
  model: monaco.editor.ITextModel,
  position: monaco.Position
): CompletionContext {
  const line = model.getLineContent(position.lineNumber);
  const col0 = position.column - 1; // 0-based
  const prefix = line.slice(0, col0);

  // Start of line (first non-whitespace)
  if (stripLeadingWs(prefix).length === 0) {
    return { kind: 'StartOfLine' };
  }

  // If we're inside quotes on this line before cursor, don't try fancy logic
  // (simple string detection: odd number of unescaped quotes)
  if (isInsideString(prefix)) {
    return { kind: 'General' };
  }

  const trimmed = stripLeadingWs(prefix);

  // Condition exists only until the first '{' AFTER the keyword on same line
  // Find keyword at the start (since grammar defines ifBlock/whileBlock as line variants)
  // This matches:  if <expr> {   or while <expr> {
  if (trimmed.startsWith('if')) {
    // Ensure it's a whole keyword (not "iff")
    if (isKeywordBoundary(trimmed, 0, 'if')) {
      // If '{' already typed before cursor, condition is over
      if (!hasOpenBraceAfterKeyword(trimmed, 'if')) return { kind: 'IfCondition' };
    }
  }

  if (trimmed.startsWith('while')) {
    if (isKeywordBoundary(trimmed, 0, 'while')) {
      if (!hasOpenBraceAfterKeyword(trimmed, 'while')) return { kind: 'WhileCondition' };
    }
  }

  return { kind: 'General' };
}

function isKeywordBoundary(text: string, start: number, kw: string): boolean {
  const before = start > 0 ? text[start - 1] : ' ';
  const after = text[start + kw.length] ?? ' ';
  const isIdentChar = (c: string) => /[a-zA-Z0-9_]/.test(c);
  return !isIdentChar(before) && !isIdentChar(after);
}

function hasOpenBraceAfterKeyword(trimmed: string, kw: 'if' | 'while'): boolean {
  // We only look at prefix (up to cursor), so:
  // If there is '{' already, cursor is after it => not in condition.
  // If there isn't '{' yet, cursor is still within condition area.
  //
  // BUT if cursor is still *before* '{' (not typed yet) => no brace in prefix => still condition.
  // So "hasOpenBraceAfterKeyword" here means: did user already type '{' in the prefix.
  const idx = trimmed.indexOf(kw);
  if (idx === -1) return false;
  const afterKw = trimmed.slice(idx + kw.length);
  return afterKw.includes('{');
}

function isInsideString(prefix: string): boolean {
  // very lightweight string detection for " and ' (handles basic escaping)
  let inDouble = false;
  let inSingle = false;
  for (let i = 0; i < prefix.length; i++) {
    const ch = prefix[i];
    const prev = i > 0 ? prefix[i - 1] : '';
    if (ch === '"' && prev !== '\\' && !inSingle) inDouble = !inDouble;
    if (ch === "'" && prev !== '\\' && !inDouble) inSingle = !inSingle;
  }
  return inDouble || inSingle;
}
