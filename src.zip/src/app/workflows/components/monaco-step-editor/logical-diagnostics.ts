import * as monaco from 'monaco-editor';

const ASSIGNMENT_REGEX = /^[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*.+$/;
const FUNCTION_CALL_REGEX = /^[a-zA-Z_][a-zA-Z0-9_]*\s*\(.*\)$/;

export function applyLogicalDiagnostics(
  model: monaco.editor.ITextModel
): monaco.editor.IMarkerData[] {
  const markers: monaco.editor.IMarkerData[] = [];
  const lines = model.getLinesContent();

  lines.forEach((line, i) => {
    const lineNumber = i + 1;
    const trimmed = line.trim();

    // empty lines are always valid
    if (!trimmed) return;

    // --- IF / WHILE need blocks ---
    if (trimmed.startsWith('if ')) {
      if (!trimmed.includes('{')) {
        markers.push(lineError(
          lineNumber,
          line,
          "Missing '{' after if condition"
        ));
      }
      return;
    }

    if (trimmed.startsWith('while ')) {
      if (!trimmed.includes('{')) {
        markers.push(lineError(
          lineNumber,
          line,
          "Missing '{' after while condition"
        ));
      }
      return;
    }

    // --- VALID STATEMENTS (whitelist) ---
    if (ASSIGNMENT_REGEX.test(trimmed)) return;
    if (FUNCTION_CALL_REGEX.test(trimmed)) return;

    // --- Unknown statement ---
    markers.push(lineError(
      lineNumber,
      line,
      'Invalid statement'
    ));
  });

  return markers;
}

function lineError(
  lineNumber: number,
  line: string,
  message: string
): monaco.editor.IMarkerData {
  return {
    severity: monaco.MarkerSeverity.Error,
    message,
    startLineNumber: lineNumber,
    startColumn: 1,
    endLineNumber: lineNumber,
    endColumn: line.length + 1,
    source: 'logic',
  };
}
