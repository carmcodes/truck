import { Component, EventEmitter, Input, Output } from '@angular/core';
import {StepDto} from '../../models/workflow-models';


@Component({
  standalone: true,
  selector: 'app-steps-sidebar',
  imports: [],
  template: `
  <div style="border:1px solid #ddd; border-radius:10px; padding:10px; height:100%; overflow:auto;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:10px;">
      <div style="font-weight:700">Steps</div>
      <button (click)="addStep.emit()">+ Add</button>
    </div>

    @for (s of steps; track s; let i = $index) {
      <div
        (click)="selectStep.emit(s.id)"
        [style.background]="s.id === selectedStepId ? '#f2f2f2' : 'transparent'"
        style="padding:10px; border-radius:10px; cursor:pointer; margin-bottom:6px; border:1px solid #eee;"
        >
        <div style="display:flex; justify-content:space-between; gap:8px; align-items:center;">
          <div>
            <div style="font-weight:600">{{ i+1 }}. {{ s.name }}</div>
            <div style="font-size:12px; opacity:.7">
              deps: {{ s.dependsOnStepIds.length }} • {{ s.cacheable ? 'cache' : 'no-cache' }}
            </div>
          </div>
          <button (click)="onDelete($event, s.id)">✕</button>
        </div>
      </div>
    }
  </div>
  `,
})
export class StepsSidebarComponent {
  @Input({ required: true }) steps: StepDto[] = [];
  @Input() selectedStepId: string | null = null;

  @Output() selectStep = new EventEmitter<string>();
  @Output() addStep = new EventEmitter<void>();
  @Output() deleteStep = new EventEmitter<string>();
  @Output() reorder = new EventEmitter<{ from: number; to: number }>();

  onDelete(ev: MouseEvent, id: string) {
    ev.stopPropagation();
    this.deleteStep.emit(id);
  }
}
