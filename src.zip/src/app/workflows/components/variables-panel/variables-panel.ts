import { Component, Input } from '@angular/core';
import {StepDto} from '../../models/workflow-models';


@Component({
  standalone: true,
  selector: 'app-variables-panel',
  imports: [],
  template: `
  <div style="border:1px solid #ddd; border-radius:10px; padding:10px; flex:1; overflow:auto;">
    <div style="font-weight:700; margin-bottom:8px;">Available Variables</div>

    @if (!step) {
      <div style="opacity:.7;">Select a step to see available variables.</div>
    }

    @if (step) {
      <div>
        @if (availableVariables.length === 0) {
          <div style="opacity:.7;">No variables detected.</div>
        }
        @for (v of availableVariables; track v) {
          <div style="padding:6px 8px; border:1px solid #eee; border-radius:10px; margin-bottom:6px;">
            <code>{{ v }}</code>
          </div>
        }
      </div>
    }
  </div>
  `,
})
export class VariablesPanelComponent {
  @Input() step: StepDto | null = null;
  @Input({ required: true }) availableVariables: string[] = [];
}
