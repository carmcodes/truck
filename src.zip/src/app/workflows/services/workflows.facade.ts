import { Injectable, computed, effect, inject, signal } from '@angular/core';
import { WorkflowsApi } from './workflows.api';
import {StepDto, WorkflowDto, WorkflowInputDto} from '../models/workflow-models';

function newId(): string {
  // simple client id generator; backend can replace on save if needed
  return crypto.randomUUID();
}

@Injectable({ providedIn: 'root' })
export class WorkflowsFacade {
  private api = inject(WorkflowsApi);

  // state
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly publishing = signal(false);
  readonly error = signal<string | null>(null);

  readonly workflow = signal<WorkflowDto | null>(null);
  readonly selectedStepId = signal<string | null>(null);

  // derived
  readonly steps = computed(() => this.workflow()?.steps ?? []);
  readonly inputs = computed(() => this.workflow()?.inputs ?? []);
  readonly selectedStep = computed(() => {
    const id = this.selectedStepId();
    return this.steps().find(s => s.id === id) ?? null;
  });

  // Build a map of available vars for a step: workflow inputs + outputs of upstream dependencies
  readonly availableVariablesForSelectedStep: any = computed(() => {
    const wf = this.workflow();
    const step = this.selectedStep();
    if (!wf || !step) return [];

    const vars: string[] = [];

    // inputs exposed as "input.<name>" (or you can expose just name)
    for (const inp of wf.inputs) {
      vars.push(`input.${inp.name}`);
    }

    const upstream = this.getUpstreamSteps(wf.steps, step.id);
    for (const s of upstream) {
      // if schema exists, expose keys; otherwise just expose step name namespace
      const schema = s.outputsSchema;
      if (schema) {
        for (const key of Object.keys(schema)) vars.push(`${s.name}.${key}`);
      } else {
        vars.push(`${s.name}.*`);
      }
    }

    return Array.from(new Set(vars)).sort();
  });

  // ------------ loading / init ------------
  async loadWorkflow(id: string) {
    this.loading.set(true);
    this.error.set(null);
    try {
      const wf = await this.api.get(id).toPromise();
      this.workflow.set(wf ?? null);
      this.selectedStepId.set(wf?.steps?.[0]?.id ?? null);
    } catch (e: any) {
      this.error.set(e?.message ?? 'Failed to load workflow');
    } finally {
      this.loading.set(false);
    }
  }

  initNewWorkflow() {
    const wf: WorkflowDto = {
      id: newId(),
      name: 'New Workflow',
      description: '',
      status: 'Draft',
      version: 0,
      updatedAt: new Date().toISOString(),
      inputs: [],
      steps: [],
    };
    this.workflow.set(wf);
    this.selectedStepId.set(null);
  }

  // ------------ editing workflow metadata ------------
  patchWorkflow(patch: Partial<WorkflowDto>) {
    const wf = this.workflow();
    if (!wf) return;
    this.workflow.set({
      ...wf,
      ...patch,
      updatedAt: new Date().toISOString(),
    });
  }

  // ------------ steps ------------
  addStep() {
    const wf = this.workflow();
    if (!wf) return;

    const step: StepDto = {
      id: newId(),
      name: `Step ${wf.steps.length + 1}`,
      description: '',
      language: 'custom',
      script: '',
      dependsOnStepIds: [],
      cacheable: false,
      enabled: true,
      outputsSchema: {}, // optional
    };

    const steps = [...wf.steps, step];
    this.workflow.set({ ...wf, steps, updatedAt: new Date().toISOString() });
    this.selectedStepId.set(step.id);
  }

  deleteStep(stepId: string) {
    const wf = this.workflow();
    if (!wf) return;

    const steps = wf.steps.filter(s => s.id !== stepId).map(s => ({
      ...s,
      dependsOnStepIds: s.dependsOnStepIds.filter(id => id !== stepId),
    }));

    this.workflow.set({ ...wf, steps, updatedAt: new Date().toISOString() });

    if (this.selectedStepId() === stepId) {
      this.selectedStepId.set(steps[0]?.id ?? null);
    }
  }

  selectStep(stepId: string) {
    this.selectedStepId.set(stepId);
  }

  patchStep(stepId: string, patch: Partial<StepDto>) {
    const wf = this.workflow();
    if (!wf) return;

    const steps = wf.steps.map(s => (s.id === stepId ? { ...s, ...patch } : s));
    this.workflow.set({ ...wf, steps, updatedAt: new Date().toISOString() });
  }

  reorderSteps(fromIndex: number, toIndex: number) {
    const wf = this.workflow();
    if (!wf) return;

    const steps = [...wf.steps];
    const [moved] = steps.splice(fromIndex, 1);
    steps.splice(toIndex, 0, moved);

    this.workflow.set({ ...wf, steps, updatedAt: new Date().toISOString() });
  }

  // ------------ inputs ------------
  addInput(kind: WorkflowInputDto['kind']) {
    const wf = this.workflow();
    if (!wf) return;

    const inp: WorkflowInputDto = {
      id: newId(),
      name: `${kind.toLowerCase()}Input${wf.inputs.length + 1}`,
      kind,
      config: {},
    };

    this.workflow.set({ ...wf, inputs: [...wf.inputs, inp], updatedAt: new Date().toISOString() });
  }

  patchInput(inputId: string, patch: Partial<WorkflowInputDto>) {
    const wf = this.workflow();
    if (!wf) return;

    const inputs = wf.inputs.map(i => (i.id === inputId ? { ...i, ...patch } : i));
    this.workflow.set({ ...wf, inputs, updatedAt: new Date().toISOString() });
  }

  deleteInput(inputId: string) {
    const wf = this.workflow();
    if (!wf) return;

    const inputs = wf.inputs.filter(i => i.id !== inputId);
    this.workflow.set({ ...wf, inputs, updatedAt: new Date().toISOString() });
  }

  // ------------ persistence ------------
  async save() {
    const wf = this.workflow();
    if (!wf) return;

    this.saving.set(true);
    this.error.set(null);
    try {
      // If backend expects POST for new, you can check version/id pattern
      const updated = await this.api.update(wf.id, wf).toPromise();
      if (updated) this.workflow.set(updated);
    } catch (e: any) {
      this.error.set(e?.message ?? 'Failed to save workflow');
    } finally {
      this.saving.set(false);
    }
  }

  async publish() {
    const wf = this.workflow();
    if (!wf) return;

    this.publishing.set(true);
    this.error.set(null);
    try {
      const res = await this.api.publish(wf.id).toPromise();
      if (res?.status === 'Failed') {
        this.error.set(res.compileErrors?.[0]?.message ?? 'Publish failed');
        return;
      }
      // optimistic update
      this.patchWorkflow({ status: 'Published', version: res?.newVersion ?? wf.version + 1 });
    } catch (e: any) {
      this.error.set(e?.message ?? 'Failed to publish workflow');
    } finally {
      this.publishing.set(false);
    }
  }

  // ------------ dependency helpers ------------
  private getUpstreamSteps(all: StepDto[], stepId: string): StepDto[] {
    const step = all.find(s => s.id === stepId);
    if (!step) return [];

    const byId = new Map(all.map(s => [s.id, s]));
    const visited = new Set<string>();
    const result: StepDto[] = [];

    const dfs = (id: string) => {
      if (visited.has(id)) return;
      visited.add(id);
      const s = byId.get(id);
      if (!s) return;
      for (const dep of s.dependsOnStepIds ?? []) dfs(dep);
      result.push(s);
    };

    for (const dep of step.dependsOnStepIds ?? []) dfs(dep);

    // return upstream in execution-ish order (deps first)
    return result;
  }

  detectCycle(): boolean {
    const steps = this.steps();
    const byId = new Map(steps.map(s => [s.id, s]));
    const visiting = new Set<string>();
    const visited = new Set<string>();

    const hasCycleFrom = (id: string): boolean => {
      if (visiting.has(id)) return true;
      if (visited.has(id)) return false;

      visiting.add(id);
      const s = byId.get(id);
      for (const dep of s?.dependsOnStepIds ?? []) {
        if (hasCycleFrom(dep)) return true;
      }
      visiting.delete(id);
      visited.add(id);
      return false;
    };

    for (const s of steps) {
      if (hasCycleFrom(s.id)) return true;
    }
    return false;
  }
}
