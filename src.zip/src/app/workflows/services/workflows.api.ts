import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import {PublishResultDto, WorkflowDto, WorkflowSummaryDto} from '../models/workflow-models';


@Injectable({ providedIn: 'root' })
export class WorkflowsApi {
  private http = inject(HttpClient);

  list() {
    return this.http.get<WorkflowSummaryDto[]>(`/workflows`);
  }

  get(id: string) {
    return this.http.get<WorkflowDto>(`/workflows/${id}`);
  }

  create(payload: Partial<WorkflowDto>) {
    return this.http.post<WorkflowDto>(`/workflows`, payload);
  }

  update(id: string, payload: WorkflowDto) {
    return this.http.put<WorkflowDto>(`/workflows/${id}`, payload);
  }

  publish(id: string) {
    return this.http.post<PublishResultDto>(`/workflows/${id}/publish`, {});
  }

  listRuns(workflowId: string) {
    return this.http.get<any[]>(`/workflows/${workflowId}/runs`);
  }

  startRun(workflowId: string, req: { inputs: Record<string, unknown> }) {
    return this.http.post<{ id: string }>(`/workflows/${workflowId}/runs`, req);
  }
}
