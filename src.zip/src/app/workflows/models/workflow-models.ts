export type Id = string;

export type WorkflowStatus = 'Draft' | 'Published';
export type ScriptLanguage = 'custom' | 'js' | 'python' | 'lua';

export type VarKind = 'bool' | 'number' | 'string' | 'object' | 'array' | 'unknown';

export interface WorkflowVar {
  name: string;
  kind: VarKind;
}

export interface WorkflowSummaryDto {
  id: Id;
  name: string;
  description?: string;
  status: WorkflowStatus;
  version: number;
  updatedAt: string;
}

export interface WorkflowDto {
  id: Id;
  name: string;
  description?: string;
  status: WorkflowStatus;
  version: number;
  updatedAt: string;

  inputs: WorkflowInputDto[];
  steps: StepDto[];
}

export interface StepDto {
  id: Id;
  name: string;
  description?: string;

  language: ScriptLanguage;
  script: string;

  dependsOnStepIds: Id[];
  cacheable: boolean;
  enabled: boolean;

  outputsSchema?: Record<string, VarSchema>;
}

export type WorkflowInputKind = 'Excel' | 'CSV' | 'JSON' | 'Text' | 'HTTP' | 'DB';

export interface WorkflowInputDto {
  id: Id;
  name: string; // variable name exposed to scripts (e.g. input.customerFile)
  kind: WorkflowInputKind;
  config: Record<string, unknown>;
}

export type VarType = 'string' | 'number' | 'bool' | 'array' | 'map' | 'object' | 'unknown';

export interface VarSchema {
  type: VarType;
  itemType?: VarSchema;
  properties?: Record<string, VarSchema>;
}

export interface PublishResultDto {
  workflowId: Id;
  newVersion: number;
  status: 'Published' | 'Failed';
  compileErrors?: CompileErrorDto[];
}

export interface CompileErrorDto {
  stepId?: Id;
  message: string;
  line?: number;
  column?: number;
}
