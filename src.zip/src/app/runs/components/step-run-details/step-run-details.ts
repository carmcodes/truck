import { Component } from '@angular/core';

@Component({
  selector: 'app-step-run-details',
  imports: [],
  templateUrl: './step-run-details.html',
  styleUrl: './step-run-details.css',
})
export class StepRunDetails {

}
