declare module 'buffer' {
  export const Buffer: any;
}
