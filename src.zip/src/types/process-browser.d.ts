declare module 'process/browser' {
  const process: any;
  export default process;
}
