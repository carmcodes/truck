import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';



import * as monaco from 'monaco-editor';
import { registerWorkflowLanguage } from './monaco-language';
import { registerWorkflowCompletion } from './monaco-completion';
import {detectContextFromGrammar} from './monaco-context';
import {WorkflowVar} from '../../models/workflow-models';
import { applyWorkflowDiagnostics} from './monaco-diagnostics';
import {applyAntlrDiagnostics} from './antlr-diagnostics';
import { extractVarsFromCode } from './script-vars';



@Component({
  standalone: true,
  selector: 'app-monaco-step-editor',
  imports: [],
  template: `<div #host class="monaco-host"></div>`,
  styleUrls: ['./monaco-step-editor.css'],
})
export class MonacoStepEditorComponent implements AfterViewInit, OnChanges {
  @ViewChild('host', { static: true }) host!: ElementRef<HTMLDivElement>;

  @Input() language: string = 'custom';
  @Input() code: string = '';
  @Input() availableVariables: WorkflowVar[] = [];

  @Output() codeChange = new EventEmitter<string>();

  private editor?: monaco.editor.IStandaloneCodeEditor;
  private model?: monaco.editor.ITextModel;
  private disposers: monaco.IDisposable[] = [];
  private diagTimer: any;
  private codeVars: WorkflowVar[] = [];

  private getAllVars(): WorkflowVar[] {
    // merge by name (external wins if type known)
    const map = new Map<string, WorkflowVar>();

    for (const v of (this.codeVars ?? [])) map.set(v.name, v);
    for (const v of (this.availableVariables ?? [])) map.set(v.name, v);

    return [...map.values()];
  }

  ngAfterViewInit(): void {
    registerWorkflowLanguage();

    registerWorkflowCompletion(() => this.availableVariables);

    this.model = monaco.editor.createModel(this.code ?? '', 'workflowLang');

    this.editor = monaco.editor.create(this.host.nativeElement, {
      model: this.model,
      automaticLayout: true,
      minimap: { enabled: false },
      fontSize: 13,
    });

    console.log('Monaco created:', !!this.editor);
    setTimeout(() => this.editor?.layout(), 0);


    this.disposers.push(
      this.model.onDidChangeContent(() => {
        const val = this.model?.getValue() ?? '';
        this.codeChange.emit(val);

        // ✅ Extract vars from code so "i" exists
        this.codeVars = extractVarsFromCode(val);

        // diagnostics (debounced if you want)
        applyWorkflowDiagnostics(this.model!);

        // ✅ If suggestion widget is open, refresh it
        this.editor?.trigger('vars-changed', 'editor.action.triggerSuggest', {});
      })
    );


// initial run
    applyWorkflowDiagnostics(this.model);
    registerWorkflowCompletion(() => this.getAllVars());


  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.model) return;

    if (changes['code'] && typeof this.code === 'string' && this.code !== this.model.getValue()) {
      this.model.setValue(this.code);
    }

    registerWorkflowCompletion(() => this.availableVariables);

    if (changes['availableVariables']) {
      registerWorkflowCompletion(() => this.getAllVars());
    }

  }

  ngOnDestroy(): void {
    this.disposers.forEach(d => d.dispose());
    this.editor?.dispose();
    this.model?.dispose();
  }
}
