import { WorkflowVar } from '../../models/workflow-models';

// Very simple extractor: finds "IDENTIFIER ="
const ASSIGN_RE = /^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=/;

export function extractVarsFromCode(code: string): WorkflowVar[] {
  const found = new Map<string, WorkflowVar>();

  const lines = code.split(/\r?\n/);
  for (const line of lines) {
    const m = line.match(ASSIGN_RE);
    if (m) {
      const name = m[1];
      if (!found.has(name)) {
        found.set(name, { name, kind: 'unknown' }); // kind can be inferred later
      }
    }
  }

  return [...found.values()];
}
