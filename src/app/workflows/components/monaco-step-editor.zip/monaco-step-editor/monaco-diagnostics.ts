import * as monaco from 'monaco-editor';
import { applyLogicalDiagnostics } from './logical-diagnostics';
import { applyAntlrDiagnostics } from './antlr-diagnostics';

export function applyWorkflowDiagnostics(model: monaco.editor.ITextModel) {
  const logical = applyLogicalDiagnostics(model);
  if (logical.length) {
    monaco.editor.setModelMarkers(model, 'workflow', logical);
    return;
  }

  const antlr = applyAntlrDiagnostics(model);
  monaco.editor.setModelMarkers(model, 'workflow', antlr);
}
